<?if(!Defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?

$hlblock_id = 2;
$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById($hlblock_id)->fetch();
$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock);
$entity_data_class = $entity->getDataClass();

$rsData = $entity_data_class::getList(
        array(
            "select" => array("*"),
            "order" => array("ID" => "ASC"),
            "filter" => array('!UF_NAME'=>false)
        )
    );
     
while($el = $rsData->fetch()){
$idForDelete = $el[ID];
echo '<pre>';print_r($el);echo '</pre>';

}
?>
<a href="?import_excel=Y">Добавить новую запись</a></br>
<a href="?delete_excel=Y">удалить запись</a></br>
<a href="?change_excel=Y">изменить запись</a></br>

<?if($_GET["import_excel"] == "Y")
{
    $arAdd = array(
        'UF_NAME' => test,
        'UF_ADDRES' => test,
        'UF_UPDATE' => '01.01.1111 01:01:01',
        'UF_CREATED' => '01.01.1111 01:01:01'
    );
$result = $entity_data_class::add($arAdd);
 
if ($result->isSuccess()){
    echo 'Запись добавлена успешно! ID записи: '. $result->getId();
} else {
    echo 'Не удалось добавить запись...';
}
} 

if($_GET["delete_excel"] == "Y")
{


$idForDelete = 17;

$result = $entity_data_class::delete($idForDelete);
}

if($_GET["change_excel"] == "Y")
{
$idForUpdate = 18;
$result = $entity_data_class::update($idForUpdate, array(
'UF_NAME'       => 'I',
'UF_ADDRES'    => 'TYT',
'UF_UPDATE'    => '01.01.1111 01:01:01',
'UF_CREATED'   => '01.01.1111 01:01:01'
));

}
?>
