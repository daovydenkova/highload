<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

if (!CModule::IncludeModule("highloadblock")) {
    die('Ошибка подключения модуля iblock');
}

/**
 * cache option check
 */
if (!isset($arParams["CACHE_TIME"])) {
    $arParams["CACHE_TIME"] = 86400;
}
  $this->includeComponentTemplate();

